import { useState, useEffect } from "react";
import axios from "axios";

import { Answer } from "./Answer.js";

// A component for a question. It display the question text and all the answers for the question. It allows the user to add more answers. It fetches the answers when initialized and whenever a new answer is added.
export function Question(props) {
  // set up state variables
  const [answers, setAnswers] = useState([]);
  const [update, setUpdate] = useState(true);
  const [text, setText] = useState("");
  // destructure the props so we don't have to keep typing 'props'
  const { question, setError } = props;

  // Call the endpoint that lets us create an answer.
  const createAnswer = async () => {
    const answer = {
      text: text,
    };
    try {
      await axios.post(`/api/questions/${question.id}/answers`, answer);
    } catch (error) {
      setError("Error creating the answer.");
    }
  };

  // This function is called when the form for creating an answer, shown below, is submitted. We create the answer and then set the update state to true so that the answers are fetched from the server again.
  const addAnswer = (e) => {
    e.preventDefault();
    createAnswer();
    setUpdate(true);
    setText("");
  };

  // We setup this effect to get the answers for this question from the server. This runs whenever update is set to true. It will also run if the question ID ever changes or the setError function ever changes. We don't expect these latter two to happen. But we could, for example, use this component to display only one question at a time on the page (the current question someone is looking at), and then change this prop, and the component would update. That's pretty cool.

  // One other oddity here is that we define the getAnswers() function inside useEffect(). This is because getAnswers() has some dependencies on props -- the question and the setError function. React wants us to declare that here instead of outside the useEffect function.
  useEffect(() => {
    const getAnswers = async () => {
      try {
        const response = await axios.get(
          `/api/questions/${question.id}/answers`
        );
        setAnswers(response.data);
      } catch (error) {
        setError("Error getting the questions.");
      }
    };
    if (update) {
      getAnswers();
      setUpdate(false);
    }
  }, [question.id, setError, update]);

  // Render the component. We use the onChange attribute in the textarea element to set the text state variable. We use the onSubmit attribute in the form element to call addAnswer.

  // Above the form, we iterate over all the answers and use the Answer comonent to show the questions. This component is in src/Answer.js. We pass one props to the Answer component -- the answer.
  return (
    <div className="question">
      <div className="problem">
        <p className="question-text">{question.text}</p>
        <div className="answers">
          <div className="answers-header">{answers.length} answers</div>
          {answers.map((answer) => (
            <Answer key={answer.id} answer={answer} />
          ))}
          <div className="answer-input">
            <form onSubmit={addAnswer}>
              <div>
                <label>
                  Your Answer:
                  <textarea
                    type="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                  />
                </label>
              </div>
              <button type="submit">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
