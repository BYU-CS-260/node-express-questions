// This is a simple component that just displays an answer. Putting this in a separate component makes it easy to add functionality later -- such as if we wanted a button to vote up good answers.
export function Answer(props) {
  return (
    <div className="answer">
      <p>{props.answer.text}</p>
    </div>
  );
}
