import { useState, useEffect } from "react";
import axios from "axios";

// We use two components, which are in src/components.
import { Error } from "./components/Error.js";
import { Question } from "./components/Question.js";

// All of the CSS for this app is in one file, for simplicity.
import "./App.css";

function App() {
  // setup state
  const [questions, setQuestions] = useState([]);
  const [update, setUpdate] = useState(true);
  const [error, setError] = useState("");
  const [text, setText] = useState("");

  // get all of the questions
  const getQuestions = async () => {
    try {
      // we use axios to get the questions from the server
      const response = await axios.get("/api/questions");
      setQuestions(response.data);
    } catch (error) {
      // if an error occurs, we set that state here
      setError("Error getting the questions.");
    }
  };

  // create a new question
  const createQuestion = async () => {
    try {
      // we use axios to create the question, using a POST request
      await axios.post("/api/questions", { text: text });
    } catch (error) {
      setError("error adding a question: " + error);
    }
  };

  // useEffect() is a hook that will run whenever the component is rendered. Here we tell it that if the update state is true, then we need to get the questions from the server. Notice that update is set to true when initialized, so we can get the questions on the first render (when the page is loaded). We set update to false after getting the questions.

  // We also list update as a dependency in the second argument to useEffect -- [update]. This means that React will rerun this effect whenever the update state variable changes. Now any other function can set update to true and that will cause the component to get the questions again.
  useEffect(() => {
    if (update) {
      getQuestions();
      setUpdate(false);
    }
  }, [update]);

  // This function is called when the user submits the form, shown below. We use e.preventDefault() to stop the browser from reloading the page. We then call a function to create the question. It is important to set the update state to true at this point. We have sent a new question to the server, but React doesn't know this. By setting update to true, this will trigger the effect, above, causing React to get the questions again, including the new one we just added.
  const addQuestion = (e) => {
    e.preventDefault();
    createQuestion();
    setUpdate(true);
    setText("");
  };

  // Render the component. We use the onChange attribute in the textarea element to set the text state variable. We use the onSubmit attribute in the form element to call addQuestion.

  // Below the form, we iterate over all the questions and use the Question comonent to show the questions. This component is in src/Question.js. We pass two props to the Question component -- the question and the setError method.
  return (
    <div className="App">
      <Error error={error} />
      <h1>Add a Question</h1>
      <form onSubmit={addQuestion}>
        <div>
          <label>
            Your Question:
            <textarea
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
          </label>
        </div>
        <button type="submit">Submit</button>
      </form>
      <h1>Questions</h1>
      {questions.map((question) => (
        <Question key={question.id} question={question} error={setError} />
      ))}
    </div>
  );
}

export default App;
